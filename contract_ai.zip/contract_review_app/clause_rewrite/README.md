﻿# clause_rewrite - Business & Tech Overview

**Purpose.** (2-3 sentences of value)
**Use cases.** (2-4 bullets)
**Inputs/Outputs.** Uses core/schemas.py (AnalysisInput/AnalysisOutput). Map other DTOs if any.
**Integration.** engine, legal_rules, report, tools, api
**Quality & SLA.** pure functions, logging, timeouts; error classes; GDPR (mask PII)
**Extensibility.** how to add modules/rules/templates safely
**DoD.** tests + docs + ADR if schemas change
